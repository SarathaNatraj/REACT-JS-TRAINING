import React from 'react';
import logo from './logo.svg';
import './App.css';

//add impoorts
import { Article } from './components/Article';
import { AddArticle } from './components/AddArticle';
import { addArticle,removeArticle } from './store/actionCreators';
import {Dispatch} from 'redux'
import { shallowEqual, useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';

const App:React.FC = () =>{

  const articles: IArticle[] = useSelector(
    (state:ArticleState) => state.articles,shallowEqual
  )

  const dispatch:Dispatch<any> = useDispatch()
  const saveArticle = React.useCallback(
    (article:IArticle) => dispatch(addArticle(article)),
    [dispatch,removeArticle]

)

  return(
    <main>
      <h1>MyArticles</h1>
      <AddArticle saveArticle={saveArticle} />
      {articles.map((article:IArticle)=>(
        <Article key={article.id} article={article} removeArticle={removeArticle} />
      ))}
    </main>
  )
}

export default App;
