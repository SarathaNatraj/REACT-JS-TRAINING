//define article type, model
interface IArticle{
    id:number,
    title:string,
    body:string
}

//define articlestate, model info
type ArticleState = {
    articles:IArticle[]
}

//define articleaction
type ArticleAction = {
    type:string,
    article:IArticle
}


//define dispatchtype
type DispatchType = (args:ArticleAction) => ArticleAction